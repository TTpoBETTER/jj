﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace ConsoleApp14
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите 10 чисел");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int e = int.Parse(Console.ReadLine());
            int q = int.Parse(Console.ReadLine());
            int w = int.Parse(Console.ReadLine());
            int h = int.Parse(Console.ReadLine());
            int l = int.Parse(Console.ReadLine());
            int n = int.Parse(Console.ReadLine());
            if (a<b)
            {
                if (b < c)
                {
                    if (c<d)
                    {
                        if (d<e)
                        {
                            if (e<q)
                            {
                                if (q<w)
                                {
                                    if (w<h)
                                    {
                                        if (h<l)
                                        {
                                            if (l<n)
                                            {
                                                Console.WriteLine("Последовательность возрастающая");
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
             else
            {
                Console.WriteLine("Последовательность невозрастающая");
            }


            Console.ReadKey();


        }
    }
}
